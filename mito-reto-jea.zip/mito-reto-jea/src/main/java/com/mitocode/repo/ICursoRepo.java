package com.mitocode.repo;

import com.mitocode.model.Curso;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ICursoRepo extends JpaRepository<Curso, Integer> {
}
