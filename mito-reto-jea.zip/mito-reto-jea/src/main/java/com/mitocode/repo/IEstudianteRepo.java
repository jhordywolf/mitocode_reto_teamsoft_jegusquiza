package com.mitocode.repo;

import com.mitocode.model.Estudiante; // Asegúrate de tener esta clase creada
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IEstudianteRepo extends JpaRepository<Estudiante, Integer> {
}
