package com.mitocode.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Matricula {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Para auto-incrementar el ID
    private Integer id;

    @Column(nullable = false)
    private LocalDate fecha; // Cambiado a LocalDate para manejar fechas

    @ManyToOne
    @JoinColumn(name = "id_estudiante", nullable = false, foreignKey = @ForeignKey(name = "FK_MATRICULA_ESTUDIANTE"))
    private Estudiante estudiante;

    @ManyToOne
    @JoinColumn(name = "id_curso", nullable = false, foreignKey = @ForeignKey(name = "FK_MATRICULA_CURSO"))
    private Curso curso;

    @Column(nullable = false, length = 10)
    private String aula;

    @Column(nullable = false)
    private Integer estado; // Estado como entero
}
