package com.mitocode.service;

import com.mitocode.exception.ModelNotFoundException;
import com.mitocode.model.Curso;
import com.mitocode.repo.ICursoRepo; // Asegúrate de tener esta interfaz creada
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CursoServiceImpl implements ICursoService {

    private final ICursoRepo repo;

    @Override
    public Curso save(Curso curso) {
        return repo.save(curso);
    }

    @Override
    public Curso update(Integer id, Curso curso) {
        curso.setId(id); // Cambié el nombre del método para establecer el ID
        repo.findById(id).orElseThrow(() -> new ModelNotFoundException("ID NOT FOUND: " + id));
        return repo.save(curso);
    }

    @Override
    public List<Curso> findAll() {
        return repo.findAll();
    }

    @Override
    public Curso findById(Integer id) {
        return repo.findById(id).orElseThrow(() -> new ModelNotFoundException("ID NOT FOUND: " + id));
    }

    @Override
    public void delete(Integer id) {
        repo.findById(id).orElseThrow(() -> new ModelNotFoundException("ID NOT FOUND: " + id));
        repo.deleteById(id);
    }
}

