package com.mitocode.service;

import com.mitocode.model.Curso;

import java.util.List;

public interface ICursoService {

    Curso save(Curso curso);
    Curso update(Integer id, Curso curso);
    List<Curso> findAll();
    Curso findById(Integer id);
    void delete(Integer id);
}