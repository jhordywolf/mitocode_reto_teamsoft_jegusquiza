package com.mitocode.service;

import com.mitocode.model.Matricula;

import java.util.List;

public interface IMatriculaService {

    Matricula save(Matricula matricula);
    Matricula update(Integer id, Matricula matricula);
    List<Matricula> findAll();
    Matricula findById(Integer id);
    void delete(Integer id);
}
