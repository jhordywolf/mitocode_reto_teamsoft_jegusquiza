package com.mitocode.service;

import com.mitocode.exception.ModelNotFoundException;
import com.mitocode.model.Matricula;
import com.mitocode.repo.IMatriculaRepo; // Asegúrate de tener esta interfaz creada
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class MatriculaServiceImpl implements IMatriculaService {

    private final IMatriculaRepo repo;

    @Override
    public Matricula save(Matricula matricula) {
        return repo.save(matricula);
    }

    @Override
    public Matricula update(Integer id, Matricula matricula) {
        matricula.setId(id);
        repo.findById(id).orElseThrow(() -> new ModelNotFoundException("ID NOT FOUND: " + id));
        return repo.save(matricula);
    }

    @Override
    public List<Matricula> findAll() {
        return repo.findAll();
    }

    @Override
    public Matricula findById(Integer id) {
        return repo.findById(id).orElseThrow(() -> new ModelNotFoundException("ID NOT FOUND: " + id));
    }

    @Override
    public void delete(Integer id) {
        repo.findById(id).orElseThrow(() -> new ModelNotFoundException("ID NOT FOUND: " + id));
        repo.deleteById(id);
    }
}
