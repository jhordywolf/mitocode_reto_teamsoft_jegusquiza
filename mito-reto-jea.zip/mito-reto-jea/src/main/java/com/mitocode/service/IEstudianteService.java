package com.mitocode.service;

import com.mitocode.model.Estudiante;

import java.util.List;

public interface IEstudianteService {

    Estudiante save(Estudiante estudiante);
    Estudiante update(Integer id, Estudiante estudiante);
    List<Estudiante> findAll();
    Estudiante findById(Integer id);
    void delete(Integer id);
}
